console.log("Welcome to client-side ZIP preview!");
export const VERSION = "1.1.6";
